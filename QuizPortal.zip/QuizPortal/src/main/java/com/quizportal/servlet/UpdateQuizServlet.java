package com.quizportal.servlet;

import com.quizportal.util.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/UpdateQuizServlet")
public class UpdateQuizServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        int quizId = Integer.parseInt(request.getParameter("quizId"));
        String text = request.getParameter("text");
        String a = request.getParameter("a");
        String b = request.getParameter("b");
        String c = request.getParameter("c");
        String d = request.getParameter("d");
        String correct = request.getParameter("correct");

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE questions SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=? WHERE question_id=?"
            );
            ps.setString(1, text);
            ps.setString(2, a);
            ps.setString(3, b);
            ps.setString(4, c);
            ps.setString(5, d);
            ps.setString(6, correct);
            ps.setInt(7, id);

            ps.executeUpdate();

            // redirect back to the quiz's questions page
            response.sendRedirect(request.getContextPath() + "/QuizQuestionsServlet?quizId=" + quizId);

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
