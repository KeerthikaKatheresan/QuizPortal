package com.quizportal.servlet;

import com.quizportal.util.DBConnection;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/CreateQuizServlet")
public class CreateQuizServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        // Session validation
        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp");
            return;
        }

        int userId = (Integer) session.getAttribute("userId");

        // Retrieve quiz data
        String quizName = request.getParameter("quizName");
        String description = request.getParameter("description");
        String category = request.getParameter("category");

        String[] questions = request.getParameterValues("questionText[]");
        String[] optionA = request.getParameterValues("optionA[]");
        String[] optionB = request.getParameterValues("optionB[]");
        String[] optionC = request.getParameterValues("optionC[]");
        String[] optionD = request.getParameterValues("optionD[]");
        String[] correctOption = request.getParameterValues("correctOption[]");

        if(questions == null || questions.length == 0) {
            response.getWriter().println("Error: No questions provided.");
            return;
        }

        Connection con = null;

        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false); // start transaction

            // Insert quiz
            PreparedStatement psQuiz = con.prepareStatement(
                "INSERT INTO quizzes (quiz_name, description, category, total_questions, created_by) VALUES (?,?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS
            );
            psQuiz.setString(1, quizName);
            psQuiz.setString(2, description);
            psQuiz.setString(3, category);
            psQuiz.setInt(4, questions.length);
            psQuiz.setInt(5, userId);
            psQuiz.executeUpdate();

            ResultSet rs = psQuiz.getGeneratedKeys();
            int quizId = 0;
            if(rs.next()) {
                quizId = rs.getInt(1);
            } else {
                throw new SQLException("Failed to get generated quiz ID.");
            }

            // Insert questions and map to quiz
            for(int i=0; i<questions.length; i++) {
                PreparedStatement psQ = con.prepareStatement(
                    "INSERT INTO questions (question_text, option_a, option_b, option_c, option_d, correct_option, created_by) VALUES (?,?,?,?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS
                );
                psQ.setString(1, questions[i]);
                psQ.setString(2, optionA[i]);
                psQ.setString(3, optionB[i]);
                psQ.setString(4, optionC[i]);
                psQ.setString(5, optionD[i]);
                psQ.setString(6, correctOption[i]);
                psQ.setInt(7, userId);
                psQ.executeUpdate();

                ResultSet rsQ = psQ.getGeneratedKeys();
                int qid = 0;
                if(rsQ.next()) {
                    qid = rsQ.getInt(1);
                } else {
                    throw new SQLException("Failed to get generated question ID.");
                }

                PreparedStatement psMap = con.prepareStatement(
                    "INSERT INTO quiz_questions (quiz_id, question_id, question_order) VALUES (?,?,?)"
                );
                psMap.setInt(1, quizId);
                psMap.setInt(2, qid);
                psMap.setInt(3, i+1);
                psMap.executeUpdate();

                psQ.close();
                psMap.close();
                rsQ.close();
            }

            con.commit(); // commit transaction
            response.sendRedirect(request.getContextPath() + "/views/adminDashboard.jsp");

        } catch(Exception e) {
            e.printStackTrace();
            try {
                if(con != null) con.rollback(); // rollback on error
            } catch(SQLException se) {
                se.printStackTrace();
            }
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try {
                if(con != null) con.setAutoCommit(true);
                if(con != null) con.close();
            } catch(SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
