package com.quizportal.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.quizportal.util.DBConnection;

@WebServlet("/EditQuestionServlet")
public class EditQuestionServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int questionId = Integer.parseInt(request.getParameter("questionId"));

        try (Connection con = DBConnection.getConnection()) {

            // Fetch question details
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM questions WHERE question_id = ?");
            ps.setInt(1, questionId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                request.setAttribute("id", rs.getInt("question_id"));
                request.setAttribute("text", rs.getString("question_text"));
                request.setAttribute("a", rs.getString("option_a"));
                request.setAttribute("b", rs.getString("option_b"));
                request.setAttribute("c", rs.getString("option_c"));
                request.setAttribute("d", rs.getString("option_d"));
                request.setAttribute("correct", rs.getString("correct_option"));
            }

            // Fetch quizId from quiz_questions
            PreparedStatement psQuiz = con.prepareStatement(
                "SELECT quiz_id FROM quiz_questions WHERE question_id = ?");
            psQuiz.setInt(1, questionId);
            ResultSet rsQuiz = psQuiz.executeQuery();
            if (rsQuiz.next()) {
                request.setAttribute("quizId", rsQuiz.getInt("quiz_id"));
            }

            request.getRequestDispatcher("views/editQuiz.jsp").forward(request, response);

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
